/* V9 independent licensing client. Server-side enforcement lives in Supabase SQL. */
(function () {
  'use strict';
  const state = { ready: false, isOwner: false, status: 'unknown', expiresAt: null, remainingDays: null, error: null };
  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  async function init() {
    if (!window.sb) throw new Error('Supabase client is unavailable');
    const { data, error } = await window.sb.rpc('ensure_app_license');
    if (error) throw error;
    Object.assign(state, {
      ready: true,
      isOwner: !!data.is_owner,
      status: data.status,
      expiresAt: data.expires_at || null,
      remainingDays: data.remaining_days ?? null,
      error: null
    });
    renderBadge();
    return state;
  }

  function canWrite() {
    return !state.ready || state.isOwner || (state.expiresAt && new Date(state.expiresAt).getTime() > Date.now());
  }

  function label() {
    if (!state.ready) return 'الترخيص غير متحقق';
    if (state.isOwner) return 'ترخيص المالك';
    if (state.status === 'expired' || !canWrite()) return 'انتهت مدة الترخيص';
    return state.status === 'trial' ? `تجربة مجانية — ${state.remainingDays} يوم` : `ترخيص نشط — ${state.remainingDays} يوم`;
  }

  function renderBadge() {
    let el = $('#licenseStatus');
    if (!el) {
      const header = document.querySelector('header');
      if (!header) return;
      el = document.createElement('div');
      el.id = 'licenseStatus';
      el.className = 'license-status';
      header.appendChild(el);
    }
    el.textContent = label();
    el.title = state.expiresAt ? `ينتهي في ${new Date(state.expiresAt).toLocaleString('ar-EG')}` : '';
    el.classList.toggle('expired', state.ready && !canWrite());
  }

  async function redeem() {
    const code = ($('#licenseCode')?.value || '').trim();
    if (!code) return alert('اكتب كود التفعيل أولًا.');
    const { data, error } = await window.sb.rpc('redeem_app_license_code', { p_code: code });
    if (error) return alert('تعذر تفعيل الكود: ' + error.message);
    await init();
    alert(`تم التفعيل بنجاح لمدة ${data.duration_days} يومًا.`);
    panel();
  }

  async function createCodes(days) {
    const qty = Number($('#licenseQty')?.value || 1);
    const { data, error } = await window.sb.rpc('admin_create_app_license_codes', {
      p_duration_days: days,
      p_quantity: qty
    });
    if (error) return alert('تعذر إصدار الأكواد: ' + error.message);
    const codes = (data.codes || []).join('\n');
    const w = window.open('', '_blank');
    if (w) {
      w.document.write(`<meta charset="utf-8"><title>أكواد التفعيل</title><body dir="rtl" style="font:16px Tahoma;padding:24px"><h2>أكواد تفعيل — ${days} يوم</h2><pre style="white-space:pre-wrap;line-height:2">${esc(codes)}</pre><button onclick="window.print()">طباعة الأكواد</button></body>`);
      w.document.close();
    } else {
      alert('تم إنشاء الأكواد. انسخها من الرسالة التالية:\n' + codes);
    }
  }

  function panel() {
    let host = $('#licensePanel');
    if (!host) {
      host = document.createElement('div');
      host.id = 'licensePanel';
      host.className = 'license-overlay';
      document.body.appendChild(host);
    }
    host.innerHTML = `<section class="license-card" dir="rtl">
      <button class="license-close" onclick="CMSLicense.close()">×</button>
      <h2>إدارة الترخيص والتفعيل</h2>
      <p class="license-state">${esc(label())}</p>
      ${state.expiresAt ? `<p>تاريخ الانتهاء: <b>${new Date(state.expiresAt).toLocaleString('ar-EG')}</b></p>` : ''}
      ${!state.isOwner ? `<label for="licenseCode">كود التفعيل</label><input id="licenseCode" autocomplete="off" placeholder="DIA-..."><button onclick="CMSLicense.redeem()">تفعيل الكود</button>` : `<hr><h3>إصدار أكواد جديدة</h3><label for="licenseQty">عدد الأكواد (1 إلى 50)</label><input id="licenseQty" type="number" min="1" max="50" value="1"><div class="license-actions">
        <button onclick="CMSLicense.createCodes(30)">إصدار 30 يومًا</button>
        <button onclick="CMSLicense.createCodes(90)">إصدار 90 يومًا</button>
        <button onclick="CMSLicense.createCodes(180)">إصدار 180 يومًا</button>
        <button onclick="CMSLicense.createCodes(365)">إصدار 365 يومًا</button>
      </div><p class="license-note">تظهر الأكواد مرة واحدة عند إصدارها. احتفظ بها في مكان آمن.</p>`}
      <div class="license-actions"><button class="secondary" onclick="CMSLicense.close()">إغلاق</button></div>
    </section>`;
    host.classList.add('show');
  }

  function close() { $('#licensePanel')?.classList.remove('show'); }
  window.CMSLicense = { state, init, canWrite, renderBadge, panel, close, redeem, createCodes };
})();
